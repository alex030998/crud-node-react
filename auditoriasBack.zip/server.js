const express = require('express');
const mysql = require('mysql2');
const { v4: uuidv4 } = require('uuid'); // Importar la librería uuid

const app = express();
app.use(express.json()); // Para poder procesar JSON en las solicitudes POST y PUT

// Configuración de la conexión a la base de datos
const db = mysql.createConnection({
  host: 'localhost',
  user: 'root',
  password: '',
  database: 'auditoria'
});

// Conectar a la base de datos
db.connect((err) => {
  if (err) {
    console.error('Error al conectar a la base de datos:', err);
    return;
  }
  console.log('Conexión a la base de datos exitosa');
});

// Ruta GET para obtener todas las auditorías
app.get('/auditorias', (req, res) => {
  const query = 'SELECT * FROM auditorias';
  db.query(query, (err, results) => {
    if (err) {
      console.error('Error al ejecutar la consulta:', err);
      res.status(500).json({ error: 'Error al ejecutar la consulta' });
      return;
    }
    res.json(results);
  });
});

// Ruta POST para crear una nueva auditoría
app.post('/crear-auditoria', (req, res) => {
  const { nombre, descripcion } = req.body;
  const id = uuidv4(); // Generar un UUID

  const query = 'INSERT INTO auditorias (id, nombre, descripcion) VALUES (?, ?, ?)';
  db.query(query, [id, nombre, descripcion], (err, results) => {
    if (err) {
      console.error('Error al insertar en la base de datos:', err);
      res.status(500).json({ error: 'Error al insertar en la base de datos' });
      return;
    }
    res.json({ message: 'Auditoría creada exitosamente', id });
  });
});

// Ruta DELETE para eliminar una auditoría por su ID
app.delete('/eliminar-auditoria/:id', (req, res) => {
  const { id } = req.params;

  const query = 'DELETE FROM auditorias WHERE id = ?';
  db.query(query, [id], (err, results) => {
    if (err) {
      console.error('Error al eliminar la auditoría:', err);
      res.status(500).json({ error: 'Error al eliminar la auditoría' });
      return;
    }

    if (results.affectedRows === 0) {
      res.status(404).json({ message: 'Auditoría no encontrada' });
    } else {
      res.json({ message: 'Auditoría eliminada exitosamente' });
    }
  });
});

// Ruta PUT para actualizar una auditoría por su ID
app.put('/auditorias/:id', (req, res) => {
  const { id } = req.params;
  const { nombre, descripcion } = req.body;

  const query = 'UPDATE auditorias SET nombre = ?, descripcion = ? WHERE id = ?';
  db.query(query, [nombre, descripcion, id], (err, results) => {
    if (err) {
      console.error('Error al actualizar la auditoría:', err);
      res.status(500).json({ error: 'Error al actualizar la auditoría' });
      return;
    }

    if (results.affectedRows === 0) {
      res.status(404).json({ message: 'Auditoría no encontrada' });
    } else {
      res.json({ message: 'Auditoría actualizada exitosamente' });
    }
  });
});

// Iniciar el servidor
app.listen(3005, '0.0.0.0', () => {
    console.log('Servidor corriendo en el puerto 3005');
  });
